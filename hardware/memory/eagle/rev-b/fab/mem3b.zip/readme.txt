Ken Rother
ken at cottageworker dot com

Order number: FXA5474ED07

component side 			mem3-b.cmp
solder side 			mem3-b.sol
silkscreen component side 	mem3-b.plc
solder stop component side 	mem3-b.stc
solder stop solder sid 		mem3-b.sts
drill file			mem3-b.drd