Ken Rother
ken at cottageworker dot com

NoTouch Order 17545-iNTJ

component side 			cpu2-a.cmp
solder side 			cpu2-a.sol
silkscreen component side 	cpu2-a.plc
solder stop component side 	cpu2-a.stc
solder stop solder sid 		cpu2-a.sts
drill file			cpu2-a.drd